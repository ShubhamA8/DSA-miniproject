import tkinter as tk
from tkinter import filedialog, messagebox
from smart_editor.editor import TextEditor
from smart_editor.smart_features import SmartFeatures

class SmartTextEditor:
    def __init__(self, root):
        self.root = root
        self.root.title("Smart Text Editor")
        self.root.geometry("800x600")
        
        self.editor = TextEditor(self.root)
        self.smart_features = SmartFeatures(self.editor.text_area)
        self.create_menu()
        
    def create_menu(self):
        menubar = tk.Menu(self.root)
        
        # File menu
        file_menu = tk.Menu(menubar, tearoff=0)
        file_menu.add_command(label="New", command=self.editor.new_file)
        file_menu.add_command(label="Open", command=self.editor.open_file)
        file_menu.add_command(label="Save", command=self.editor.save_file)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.root.quit)
        menubar.add_cascade(label="File", menu=file_menu)
        
        # Edit menu
        edit_menu = tk.Menu(menubar, tearoff=0)
        edit_menu.add_command(label="Cut", command=self.editor.cut_text)
        edit_menu.add_command(label="Copy", command=self.editor.copy_text)
        edit_menu.add_command(label="Paste", command=self.editor.paste_text)
        menubar.add_cascade(label="Edit", menu=edit_menu)
        
        self.root.config(menu=menubar)

if __name__ == "__main__":
    root = tk.Tk()
    app = SmartTextEditor(root)
    root.mainloop()
