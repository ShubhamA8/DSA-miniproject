from smart_editor.main import SmartTextEditor
import tkinter as tk

def test_editor():
    root = tk.Tk()
    editor = SmartTextEditor(root)
    root.mainloop()

if __name__ == "__main__":
    test_editor()
