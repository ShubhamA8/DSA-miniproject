import tkinter as tk
from tkinter import ttk
import re

class SmartFeatures:
    def __init__(self, text_widget):
        self.text = text_widget
        self.setup_autocomplete()
        self.setup_syntax_highlighting()
        
    def setup_autocomplete(self):
        self.autocomplete_words = [
            'print', 'def', 'class', 'import', 'from',
            'if', 'else', 'elif', 'for', 'while', 'return'
        ]
        self.autocomplete_window = None
        self.autocomplete_listbox = None
        self.text.bind('<KeyRelease>', self.check_autocomplete)
        
    def check_autocomplete(self, event):
        if event.keysym in ('BackSpace', 'Return', 'Up', 'Down', 'Left', 'Right'):
            return
            
        word = self.get_current_word()
        if word:
            matches = [w for w in self.autocomplete_words if w.startswith(word)]
            if matches:
                self.show_autocomplete(matches)
            else:
                self.hide_autocomplete()
        else:
            self.hide_autocomplete()
            
    def get_current_word(self):
        pos = self.text.index(tk.INSERT)
        line = pos.split('.')[0]
        col = pos.split('.')[1]
        line_text = self.text.get(f"{line}.0", f"{line}.end")
        
        # Get the word being typed
        word_start = line_text.rfind(' ', 0, int(col)) + 1
        word_end = line_text.find(' ', int(col))
        if word_end == -1:
            word_end = len(line_text)
            
        return line_text[word_start:word_end]
        
    def show_autocomplete(self, matches):
        if self.autocomplete_window:
            self.autocomplete_listbox.delete(0, tk.END)
        else:
            self.autocomplete_window = tk.Toplevel(self.text.master)
            self.autocomplete_listbox = tk.Listbox(
                self.autocomplete_window,
                height=min(len(matches), 5),
                width=20
            )
            self.autocomplete_listbox.pack()
            self.autocomplete_listbox.bind('<Double-Button-1>', self.select_autocomplete)
            
        for match in matches:
            self.autocomplete_listbox.insert(tk.END, match)
            
        pos = self.text.index(tk.INSERT)
        x, y = self.text.bbox(pos)[0], self.text.bbox(pos)[1] + self.text.bbox(pos)[3]
        self.autocomplete_window.geometry(f"+{x + self.text.winfo_rootx()}+{y + self.text.winfo_rooty()}")
        
    def hide_autocomplete(self):
        if self.autocomplete_window:
            self.autocomplete_window.destroy()
            self.autocomplete_window = None
            
    def select_autocomplete(self, event):
        if self.autocomplete_listbox.curselection():
            word = self.autocomplete_listbox.get(self.autocomplete_listbox.curselection())
            self.hide_autocomplete()
            
            pos = self.text.index(tk.INSERT)
            line = pos.split('.')[0]
            col = pos.split('.')[1]
            line_text = self.text.get(f"{line}.0", f"{line}.end")
            
            word_start = line_text.rfind(' ', 0, int(col)) + 1
            self.text.delete(f"{line}.{word_start}", pos)
            self.text.insert(pos, word)
            
    def setup_syntax_highlighting(self):
        self.text.tag_configure('keyword', foreground='blue')
        self.text.tag_configure('string', foreground='green')
        self.text.tag_configure('comment', foreground='gray')
        
        self.text.bind('<KeyRelease>', self.highlight_syntax)
        
    def highlight_syntax(self, event):
        if event.keysym in ('BackSpace', 'Return', 'Up', 'Down', 'Left', 'Right'):
            return
            
        # Clear previous tags
        for tag in ['keyword', 'string', 'comment']:
            self.text.tag_remove(tag, '1.0', tk.END)
            
        # Highlight keywords
        for word in self.autocomplete_words:
            start = '1.0'
            while True:
                pos = self.text.search(word, start, stopindex=tk.END, regexp=True)
                if not pos:
                    break
                end = f"{pos}+{len(word)}c"
                self.text.tag_add('keyword', pos, end)
                start = end
                
        # Highlight strings
        self.highlight_pattern(r'"[^"]*"', 'string')
        self.highlight_pattern(r"'[^']*'", 'string')
        
        # Highlight comments
        self.highlight_pattern(r'#.*$', 'comment', multiline=False)
        
    def highlight_pattern(self, pattern, tag, multiline=True):
        start = '1.0'
        flags = 0
        if multiline:
            flags = re.MULTILINE
            
        while True:
            pos = self.text.search(pattern, start, stopindex=tk.END, regexp=True)
            if not pos:
                break
            end = self.text.index(f"{pos}+{len(self.text.get(pos, tk.END).splitlines()[0])}c")
            self.text.tag_add(tag, pos, end)
            start = end
